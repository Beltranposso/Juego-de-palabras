/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.clasesolu;

import javax.swing.Timer;



/**
 *
 * @author Alejandro
 */
public class Clasesolu {
   
// variables inicializadas 
    public int contarpalbras= 0;
    public String letra ; 
   
   
    
    public String [] palabras; 
        Clasesolu(String[] palabras){
            this.palabras = palabras;
        
        }
     // esta funcion entrega el contenido del array 
         public void ramdonspalbras(){
           
         String []pa =(this.palabras != null)?this.palabras:null;
         
            for(String p: pa){
                System.out.println("palabra seleccionada:: "+p);
                 
            } 
        }
       // esta funcion contiene el las plabras que utilizamaos en el cdigo
         public void setPalabras(){
            String [] banco={"hola","bar","silla","retrato","casa","tutancamon","hola","raiz","coco","mañana","negro","azul","prota","raton","cerpiente","azucar","leña",};
            this.palabras = new String [banco.length];
               while(contarpalbras < banco.length){
            this.palabras[contarpalbras]=banco[(int)((Math.random()*banco.length))];
            contarpalbras ++;
            
        }
        }
       
             //esta funcion retorna una palabra del banco de palabras segun su pocicion
         public String escupepalbr() {
                 
                   String []pa =(this.palabras != null)?this.palabras:null;
                   int numero = (int)(Math.random()*pa.length+1);
                   return pa[numero];
             }
             
             public static void main(String[]args) {

             
            
            }
        }
